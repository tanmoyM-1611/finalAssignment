// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyA3Wi2Mynem31Q4LEZDRRul0nJfpE4OQeg",
  authDomain: "fresh-valley-75b0d.firebaseapp.com",
  projectId: "fresh-valley-75b0d",
  storageBucket: "fresh-valley-75b0d.appspot.com",
  messagingSenderId: "970440791639",
  appId: "1:970440791639:web:7611e03fffcdd945c03512"
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);